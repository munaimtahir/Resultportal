Models: Result, ImportBatch, GradeScale
