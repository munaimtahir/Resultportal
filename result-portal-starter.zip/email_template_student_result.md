Subject: Your Pathology Exam Result – 2nd Year MBBS (E Block), 2025

Dear {{ name }},

Here are your results for the 2nd Year MBBS (E Block) Pathology Examination 2025:

- Written Marks: {{ written }}
- Viva/OSPE Marks: {{ viva }}
- Total Marks: {{ total }}
- Grade: {{ grade }}

These results are provisional and subject to confirmation by the Examination Department.
If you have questions, please contact the course coordinator.

Best regards,
Examination Department
Aziz Fatima Medical & Dental College